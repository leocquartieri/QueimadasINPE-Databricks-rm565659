# Checkpoint 02 — Cloud Databricks → MySQL (Azure)

Roteiro na ordem do enunciado (valor total 11,0). Cada etapa termina com a **evidência** a ser printada. Todo print precisa mostrar o **RM** ou o **nome do repositório**.

## 0. Antes de começar

- Pasta `checkpoint02/` deste pacote = repositório-base ajustado. Crie um **repositório novo** no GitHub (ex.: `QueimadasINPE-Databricks-RM000000`) e suba todo o conteúdo.
- No arquivo `.github/workflows/terraform-apply.yml`, troque `RM: "rm000000"` pelo RM em minúsculas (ex.: `rm565659`).
- Em *Settings → Secrets and variables → Actions → Repository secrets* crie:
  - `AZURE_CREDENTIALS`: JSON do service principal (`az ad sp create-for-rbac --sdk-auth --role Contributor --scopes /subscriptions/<ID>`).
  - `MYSQL_ADMIN_PASSWORD`: senha forte (mín. 8 caracteres, maiúscula, minúscula, número e símbolo).

O que foi ajustado em relação ao repositório do professor:

| Arquivo | Ajuste | Motivo |
|---|---|---|
| `infra/provider.tf` | backend com configuração parcial; provider Databricks removido | o backend original apontava para uma storage account de outra pessoa; o provider Databricks não era usado |
| workflow | passo que cria RG + storage do state e passa o `-backend-config` | sem isso o `terraform init` falha |
| `infra/variables.tf`, `main.tf` | região `brazilsouth`, sem `zone` fixa | `chilecentral` e zona 3 costumam falhar em assinatura de aluno |
| `01_bronze` | se não vier `input_file_path`, pega o CSV mais novo do volume ainda não auditado | o gatilho *File arrival* não passa o caminho do arquivo; sem isso a task Bronze dá erro |
| `03_gold` | host/usuário/senha em variáveis simples | preencher com seus dados (não commitar a senha) |

## 1. MySQL Flexible Server via GitHub Actions (2,0)

1. Actions → `provision-mysql-queimadas` → **Run workflow**.
2. Aguarde o check verde (~7 min).

**Evidência:** link da execução da action, no formato `https://github.com/<usuario>/<repo>/actions/runs/<id>`. Anote também o `mysql_fqdn` mostrado no último passo (*Mostrar outputs*).

## 2. Catálogo, schemas e volume (1,0)

No Databricks, abra um notebook (ou o SQL Editor) e rode:

```sql
CREATE CATALOG IF NOT EXISTS inpe;
CREATE SCHEMA IF NOT EXISTS inpe.bronze;
CREATE SCHEMA IF NOT EXISTS inpe.silver;
CREATE SCHEMA IF NOT EXISTS inpe.gold;
CREATE VOLUME IF NOT EXISTS inpe.bronze.arquivo;
```

Se o workspace não permitir criar catálogo, use *Catalog → Create catalog* na interface (tipo *Standard*).

**Evidência:** Catalog Explorer expandido em `inpe → bronze → Volumes → arquivo`, com o painel do volume mostrando o *Owner* (seu e-mail institucional).

## 3. Notebooks das três camadas (1,0)

1. *Workspace → Create → Notebook* (um para cada), com estes nomes:
   - `Camada Bronze — ingestão "raw"` ← `databricks/01_bronze_csv_ingest.py`
   - `Camada Silver — limpeza e qualidade de dados` ← `databricks/02_silver_standardize_quality.py`
   - `Camada Gold - Armazenamento` ← `databricks/03_gold_publish_mysql.py`
   Alternativa mais rápida: *Import* dos três `.py` (eles já têm o cabeçalho de notebook).
2. No notebook Gold, preencha `mysql_host` (FQDN do passo 1) e `mysql_password`.

**Evidência:** lista do Workspace mostrando os três notebooks.

## 4. Job com gatilho de chegada de arquivo (3,0)

1. *Jobs & Pipelines → Create job*, nome `queimadasINPE`.
2. Três tasks encadeadas, todas em **Serverless**: `bronze` → `silver` (depende de bronze) → `gold` (depende de silver), cada uma apontando para o notebook correspondente.
3. *Schedules & Triggers → Add trigger*: tipo **File arrival**, *Storage location* = `/Volumes/inpe/bronze/arquivo/`, status **Active**.
4. Deixe **sem** parâmetros de job (o Bronze já descobre o arquivo sozinho).

**Evidência:** aba *Tasks* com o grafo bronze → silver → gold e, no painel lateral, *Creator/Run as* e o gatilho *File arrival* ativo.

## 5. Subir os três CSV no volume (1,0)

1. Baixe três arquivos mensais em
   `https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/mensal/Brasil/`
   (o exemplo do professor usa `focos_mensal_br_202607.csv`, `..._202608.csv` e `..._202609.csv`; use os meses disponíveis na época).
2. No volume: **Upload to this volume**, um arquivo por vez. **Espere cada execução do job terminar (≈1 min 15 s) antes de subir o próximo**, para obter 3 execuções separadas e não perder nenhum arquivo.

**Evidência:** página do volume `arquivo` na aba *Overview* com os três arquivos (nome, tamanho, data) e o *Owner*.

## 6. Execuções do job

Aba *Runs* do job `queimadasINPE`: 3 execuções, *Launched: By file arrival*, status *Succeeded*. O enunciado pede acompanhamento; vale como evidência complementar.

## 7. Tabelas e contagens no MySQL (3,0)

No portal Azure, abra o **Cloud Shell (Bash)** e conecte (o FQDN está nos outputs do Terraform):

```bash
mysql -h <mysql_fqdn> -u queimadasadmin -p queimadas
```

Dentro do MySQL:

```sql
SHOW TABLES;
SELECT COUNT(*) FROM gold_focos_bioma_dia;
SELECT COUNT(*) FROM gold_focos_estado_dia;
SELECT COUNT(*) FROM gold_municipios_criticidade;
```

Resultado esperado: 3 tabelas (`gold_focos_bioma_dia`, `gold_focos_estado_dia`, `gold_municipios_criticidade`).

**Evidência:** print do terminal com o comando de conexão, `SHOW TABLES` e os três `COUNT(*)`, com o canto superior direito do portal mostrando seu e-mail (identifica o aluno). A senha digitada não aparece no terminal.

## Pontos de atenção

- **Custo/limpeza:** depois da entrega, apague no portal Azure o resource group `rg-queimadas-dbx-aula` (e o `rg-tfstate`, se não for reutilizar) para não consumir crédito. O workflow não tem passo de `destroy`.
- **Firewall:** `main.tf` mantém a regra `AllowAllIP` do professor para o Databricks e o Cloud Shell alcançarem o banco. Serve para o checkpoint; não use assim em produção.
- **Acentos:** a Silver corrige textos como `PARÃ` → `PARÁ`. Se os CSV baixados já vierem corretos, isso não causa dano; se aparecer lixo diferente nas colunas `estado`/`municipio`, troque `.option("encoding", "UTF-8")` por `"ISO-8859-1"` na Bronze.
- **Sem execução em duplicidade:** a Silver usa `append`; se rodar o job manualmente sobre o mesmo arquivo, os registros duplicam na Silver (a Gold reflete isso). Para refazer do zero: `DROP TABLE inpe.silver.queimadas_focos;` e `DROP TABLE inpe.bronze.auditoria_ingestao;`.
- Não consegui executar nada no seu Azure/Databricks nem baixar os CSV do INPE daqui: os scripts foram ajustados por leitura e não foram testados em ambiente real.
